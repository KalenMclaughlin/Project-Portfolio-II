﻿using System;
using System.Collections.Generic;
using System.IO;
using MySql.Data.MySqlClient;
namespace MclaughlinKalen_Integrative2
{
    public class Database
    {
        public static void Data2()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY RestaurantName, OverallRating ASC";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    decimal.Round(oRating);
                    External rating = new External();
                    Console.WriteLine("==============================");
                    Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating.Rating(oRating));
                    Console.WriteLine("==============================");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data3()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY RestaurantName DESC, OverallRating DESC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (oRating == 5)
                    {
                        string rating = "*****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 4)
                    {
                        string rating = "****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");

                    }
                    else if (oRating >= 3)
                    {
                        string rating = "***";
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating == 2)
                    {
                        string rating = "**";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 1)
                    {
                        string rating = "*";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }

                    else if (oRating >= 0)
                    {
                        string rating = "This restaurant has no ratings!";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        public static void Data4()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating DESC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (oRating == 5)
                    {
                        string rating = "*****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 4)
                    {
                        string rating = "****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");

                    }
                    else if (oRating >= 3)
                    {
                        string rating = "***";
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating == 2)
                    {
                        string rating = "**";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 1)
                    {
                        string rating = "*";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }

                    else if (oRating >= 0)
                    {
                        string rating = "This restaurant has no ratings!";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }



                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data5()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (oRating == 5)
                    {
                        string rating = "*****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 4)
                    {
                        string rating = "****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");

                    }
                    else if (oRating >= 3)
                    {
                        string rating = "***";
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating == 2)
                    {
                        string rating = "**";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else if (oRating >= 1)
                    {
                        string rating = "*";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }

                    else if (oRating >= 0)
                    {
                        string rating = "This restaurant has no ratings!";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }



                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data6()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (oRating == 5)
                    {
                       
                        string rating = "*****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        public static void Data7()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
  
                    if (oRating >= 4)
                    {
                        string rating = "****";
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");

                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data8()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
        
                    if (oRating >= 3)
                    {
                        string rating = "***";
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        public static void Data9()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (decimal.Round(oRating) == 1)
                    {
                        string rating = "*";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
                    else
                    {
                        Console.WriteLine("There are no restaurants that have a 4 SAtars and Up rating that start with X and Up.");
                    }

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        public static void Data10()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;
            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT RestaurantName, OverallRating FROM RestaurantProfiles ORDER BY OverallRating ASC";

                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);

                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    if (decimal.Round(oRating) == 0)
                    {
                        string rating = "This restaurant has no ratings!";
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("==============================");
                        Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating);
                        Console.WriteLine("==============================");
                    }
       
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }

        }
        public static void Data11()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Sample Restaurant Database;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT ReviewScore, PossibleReviewScore FROM RestaurantReviews";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string restaurantName = rdr["RestaurantName"].ToString();
                    string overallRating = rdr["OverallRating"].ToString();
                    decimal.TryParse(overallRating, out decimal oRating);
                    decimal.Round(oRating);
                    External rating = new External();
                    Console.WriteLine("==============================");
                    Console.WriteLine("RestaurantName: " + restaurantName + " OverallRating: " + rating.Rating(oRating));
                    Console.WriteLine("==============================");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
    }
}
