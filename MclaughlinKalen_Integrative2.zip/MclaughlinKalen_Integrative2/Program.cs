﻿using System;

namespace MclaughlinKalen_Integrative2
{
    class Program
    {
        static void Main(string[] args)
        {
            Assignment assignment = new Assignment();
        }
    }
}
