﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
namespace MclaughlinKalen_TimeTracker
{
    public class Database
    {

        public Database()
        {

        }
        public static void Data()
        {

            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();


                // Form SQL Statement
                string stm = "SELECT user_firstname, user_lastname FROM time_tracker_users WHERE user_firstname = 'Kalen' AND user_lastname = 'Mclaughlin'";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string firstName = rdr["user_firstname"].ToString();
                    string lastName = rdr["user_lastname"].ToString();

                    Console.WriteLine("Hello " + firstName + " " + lastName);

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }



        }
        public static void Data1()
        {

            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            MySqlDataReader rdr;



            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {


                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT category_description FROM activity_categories ";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {

                    string categoryDescription = rdr["category_description"].ToString();

                    Console.WriteLine("=========================");
                    Console.WriteLine(categoryDescription);
                    Console.WriteLine("=========================");


                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        public static void Data2()
        {

            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;



            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT activity_description FROM activity_descriptions ";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string activityDescription = rdr["activity_description"].ToString();
                    Console.WriteLine("=========================");
                    Console.WriteLine(activityDescription);
                    Console.WriteLine("=========================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data3()
        {

            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT calendar_date FROM tracked_calendar_dates ";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string calendarDate = rdr["calendar_date"].ToString();
                    DateTime calendarDate1 = Convert.ToDateTime(calendarDate);
                    Console.WriteLine("=========================");
                    Console.WriteLine(calendarDate1.Year + "-" + calendarDate1.Month + "-" + calendarDate1.Day);
                    Console.WriteLine("=========================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data4()
        {

            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            MySqlDataReader rdr;

            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT time_spent_on_activity FROM activity_times ";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string time = rdr["time_spent_on_activity"].ToString();
                    decimal time1 = Convert.ToDecimal(time);
                    Console.WriteLine("=========================");
                    Console.WriteLine(time1);
                    Console.WriteLine("=========================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data5()
        {
            //Assignment myWork = new Assignment();
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=KalenMclaughlin_MDV229_Database_C202003;port=8889";
            // Declare a MySQL Connection
            MySqlConnection conn = null;
            // This code block is assigning strings to the index values of userdata and tryparse the strings to become an int and datetime.
            // I did that because in the sequel database date is datetime and time is double
            List<string> userData = new List<string>();
            userData = Input();
            string categoryOfActivity = userData[0];
            string activityDescription = userData[1];
            string longPerformActivity = userData[2];
            string datePerformActivity = userData[3];
            Int32.TryParse(categoryOfActivity, out int CategoryOfActivity);
            Int32.TryParse(activityDescription, out int ActivityDescription);
            Int32.TryParse(datePerformActivity, out int DatePerfromActivity);
            Int32.TryParse(longPerformActivity, out int LongPerformActivity);
            


            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "INSERT INTO activity_log (user_id, category_description, activity_description, time_spent_on_activity, calendar_date) VALUES(@category_description, @activity_description, @time_spent_on_activity, @calendar_date)";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                cmd.Parameters.AddWithValue("@category_description", CategoryOfActivity);
                cmd.Parameters.AddWithValue("@activity_description", ActivityDescription);
                cmd.Parameters.AddWithValue("@time_spent_on_activity", LongPerformActivity);
                cmd.Parameters.AddWithValue("@calendar_date", DatePerfromActivity);
                cmd.ExecuteNonQuery();
               
               
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static List<string> Input()
        {
            var userData = new List<string>();

            Console.Clear();
            string input = Validation.ValidateString("Please pick a category:");
            userData.Add(input);
            string activityInput = Validation.ValidateString("Please enter an activity:");
            userData.Add(activityInput);
            string dateInput = Validation.ValidateString("What date did you perform activity?");
            userData.Add(dateInput);
            string timeInput = Validation.ValidateString("How long did you perform that activity?");
            userData.Add(timeInput);
            return userData;
        }
    }
}
    
