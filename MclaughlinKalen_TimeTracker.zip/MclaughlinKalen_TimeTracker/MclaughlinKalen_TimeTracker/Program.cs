﻿using System;

namespace MclaughlinKalen_TimeTracker
{
    class Program
    {
        static void Main(string[] args)
        {
            Assignment assignment = new Assignment();
            
        }
    }
}
