﻿using System;
using System.IO;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
namespace MclaughlinKalen_TimeTracker
{
    public class Assignment
    {
        private Menu _mymenu;
        //public List<string> userInput = new List<string>();
        
      

        public Assignment()
        {
            Database.Data();
           // this displays the menu
            _mymenu = new Menu("Enter Activity", "View Tracked Data", "Run Calculations", "Exit");
            _mymenu.Title = "Time Tracker Menu";
            _mymenu.Display();
            Selection();


        }
        private void Selection()
        {
            int choice = Validation.ValidateInt("What would you like to do today ?");
            switch (choice)
            {
                case 1:
                    Activity();
                    Continue();
                    break;
                case 2:
                    TrackedData();
                    Continue();
                    break;
                case 3:
                    Calculations();
                    Continue();
                    break;
                case 4:
                    Console.WriteLine("Thank you for checking out my time tracker menu.");
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue();
                    break;
            }
        }
        private void Selection2()
        {
            _mymenu = new Menu("Category Of Activity","Activity Description", "What Date Did You Perform Activity", "How Long Did You Perform That Activity","Feedback","Back");
            _mymenu.Display();
            int choice = Validation.ValidateInt("What would you like to do today ?");
            switch (choice)
            {
                case 1:
                    Category();
                    Continue2();
                    break;
                case 2:
                    activityDescription();
                    Continue2();
                    break;
                case 3:
                    Date();
                    Continue2();
                    break;
                case 4:
                    timePerformed();
                    Continue2();
                    break;
                case 5:
                    Feedback();
                    Continue2();
                    break;
                case 6:
                    BackToMenu();
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue2();
                    break;
            }
        }
        private void Feedback()
        {
            Console.Clear();
            Database.Data5();
            Console.WriteLine("Your activity has been entered. Press The Return Key To Go Back To Previous Menu...");
            
        }
        private void timePerformed()
        {
            Console.Clear();
            Database.Data4();
            //string timeInput = Validation.ValidateString("How long did you perform that activity?");
            //userInput.Add(timeInput);
            
            
        }
        private void Date()
        {
            Console.Clear();
            Database.Data3();
            //string dateInput = Validation.ValidateString("What date did you perform activity?");
            //userInput.Add(dateInput);
           
          
        }
        private void activityDescription()
        {
            Console.Clear();
            Database.Data2();
            //string activityInput = Validation.ValidateString("Please enter an activity:");
            //userInput.Add(activityInput);
            
        }
        private void BackToMenu()
        {
            _mymenu = new Menu("Enter Activity", "View Tracked Data", "Run Calculations", "Exit");
            _mymenu.Title = "Time Tracker Menu";
            _mymenu.Display();
            Selection();

        }
        private void Category()
        {
            Console.Clear();
            Database.Data1();
            //string input = Validation.ValidateString("Please pick a category:");
            //userInput.Add(input);
           
           
        }
        private void Activity()
        {
            Console.Clear();
            Selection2();
            
        }
        private void TrackedData()
        {
            Console.Clear();
        }
        private void Calculations()
        {
            Console.Clear();
        }
        private void Continue()
        {
            Console.WriteLine("Press The Return Key To Go Back To The Main Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection();
        }
        private void Continue2()
        {
            Console.WriteLine("Press The Return Key To Go Back To Previous Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection2();
        }
    }
}
