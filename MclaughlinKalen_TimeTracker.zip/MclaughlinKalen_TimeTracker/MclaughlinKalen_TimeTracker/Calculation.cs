﻿using System;
namespace MclaughlinKalen_TimeTracker
{
    public class Calculation
    {
        public Calculation()
        {
        }
    }
}
