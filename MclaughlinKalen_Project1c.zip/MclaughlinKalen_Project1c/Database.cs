﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
namespace MclaughlinKalen_Project1c
{
    public class Database
    {
        public static void Data()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT firstName, lastName FROM userProfile WHERE firstName = 'Emma' AND lastName = 'Smith'";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string firstname = rdr["firstName"].ToString();
                    string lastname = rdr["lastName"].ToString();
                    Console.WriteLine("Welcome " + firstname + " " + lastname);
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data2()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT workoutName, Difficulty, bodyPart, Minutes, Calories, Equipment FROM Workouts";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string workoutname = rdr["workoutName"].ToString();
                    string difficulty = rdr["Difficulty"].ToString();
                    string bodypart = rdr["bodyPart"].ToString();
                    string minutes = rdr["Minutes"].ToString();
                    string calories = rdr["Calories"].ToString();
                    string equipment = rdr["Equipment"].ToString();
                    Console.WriteLine("=================================");
                    Console.WriteLine("Workout Name: " + workoutname);
                    Console.WriteLine("Difficulty: " + difficulty);
                    Console.WriteLine("Body Part: " + bodypart);
                    Console.WriteLine("Minutes: " + minutes);
                    Console.WriteLine("Calories: " + calories);
                    Console.WriteLine("Equipment: " + equipment);
                    Console.WriteLine("=================================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data3()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT Sports, Calories FROM Activities";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string sports = rdr["Sports"].ToString();
                    string calories = rdr["Calories"].ToString();
                    Console.WriteLine("=================================");
                    Console.WriteLine("Sports: " + sports);
                    Console.WriteLine("Calories: " + calories);
                    Console.WriteLine("=================================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data4()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT Food, Fat, Calories FROM Food";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string food = rdr["Food"].ToString();
                    string fat = rdr["Fat"].ToString();
                    string calories = rdr["Calories"].ToString();
                    Console.WriteLine("=================================");
                    Console.WriteLine("Food: " + food);
                    Console.WriteLine("Fat: " + fat);
                    Console.WriteLine("Calories: " + calories);
                    Console.WriteLine("=================================");

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
        public static void Data5()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            // Declare a MySQL Connection
            MySqlConnection conn = null;


            // This code block is assigning strings to the index values of userdata and tryparse the strings to become ints
            List<string> userData = new List<string>();
            userData = CreateAccount();
            string firstName = userData[0];
            string lastName = userData[1];
            string Age = userData[2];
            string Gender = userData[3];
            string Email = userData[4];
            string State = userData[5];
            string City = userData[6];
            string Zipcode = userData[7];
            Int32.TryParse(Age, out int age);
            Int32.TryParse(Zipcode, out int zipcode);
           

          
 
                try
                {
                    // Open a connection to MySQL
                    conn = new MySqlConnection(cs);
                    conn.Open();
                    string stm = $"INSERT INTO userProfile (firstName, lastName, Age, Gender, Email, State, City, Zipcode) VALUES (@firstName,@lastName,@age,@Gender,@Email,@State,@City,@zipcode)";
                    // This code block is data binding the columns in the database to data that I want to push 
                    MySqlCommand cmd = new MySqlCommand(stm, conn);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@Age", age);
                cmd.Parameters.AddWithValue("@Gender", Gender);
                cmd.Parameters.Add("@Email", MySqlDbType.VarChar).Value = Email;
                cmd.Parameters.AddWithValue("@State", State);
                cmd.Parameters.AddWithValue("@City", City);
                cmd.Parameters.AddWithValue("@Zipcode", zipcode);
                cmd.ExecuteNonQuery();

                   

                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("Error: {0}", ex.ToString());
                }


               
            
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
             }
          
        }
        // This method is grabbing all of the user input and adding it into a list and returning that list.
        public static List<string> CreateAccount()
        {
           var userData = new List<string>();
            
            Console.Clear();
            string firstName = Validation.ValidateString("Please enter your first name:");
            userData.Add(firstName);
            string lastName = Validation.ValidateString("Please enter your last name:");
            userData.Add(lastName);
            string Age = Validation.ValidateString("Please enter your age");
            userData.Add(Age);
            string Gender = Validation.ValidateString("Please enter your gender (M or F):");
            userData.Add(Gender);
            string Email = Validation.ValidateString("Please enter your email:");
            userData.Add(Email);
            string State = Validation.ValidateString("Please enter your state:");
            userData.Add(State);
            string City = Validation.ValidateString("Please enter your city");
            userData.Add(City);
            string Zipcode = Validation.ValidateString("Please enter your zipcode");
            userData.Add(Zipcode);

            return userData;
         


        }
        public static void Data6()
        {
            // MySQL Database Connection String
            string cs = @"server=127.0.0.1;userid=root;password=root;database=Gym;port=8889";
            MySqlDataReader rdr;


            // Declare a MySQL Connection
            MySqlConnection conn = null;

            try
            {
                // Open a connection to MySQL
                conn = new MySqlConnection(cs);
                conn.Open();

                // Form SQL Statement
                string stm = "SELECT Exercises, Difficulty, exerciseType, bodyPart FROM Exercises";
                // Prepare SQL Statement
                MySqlCommand cmd = new MySqlCommand(stm, conn);
                rdr = cmd.ExecuteReader();
                // read is looking at data returned to us
                // When it reaches end of data it will break out of the while loop
                while (rdr.Read())
                {
                    string exercises = rdr["Exercises"].ToString();
                    string difficulty = rdr["Difficulty"].ToString();
                    string exerciseType = rdr["exerciseType"].ToString();
                    string bodyPart = rdr["bodyPart"].ToString();
                    Console.WriteLine("=================================");
                    Console.WriteLine("Exercises: " + exercises);
                    Console.WriteLine("Difficulty: " + difficulty);
                    Console.WriteLine("Exercise Type: " + exerciseType);
                    Console.WriteLine("Body Part: " + bodyPart);
                    Console.WriteLine("=================================");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString());
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

    }
}
