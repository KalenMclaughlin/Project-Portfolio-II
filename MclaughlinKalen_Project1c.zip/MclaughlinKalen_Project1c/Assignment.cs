﻿using System;
namespace MclaughlinKalen_Project1c
{
    public class Assignment
    {
        private Menu _mymenu;

        public Assignment()
        {
            // This code call the data method inside the database class
            Database.Data();
            // this displays the menu
            _mymenu = new Menu("Create Account", "Show All Workouts", "Show all Activities", "Show All Food","Show All Exercise", "Exit");
            _mymenu.Title = "Big Gains";
            _mymenu.Display();
            Selection();



        }
        // This method let the user make a selection inside the menu
        private void Selection()
        {
            int choice = Validation.ValidateInt("Welcome to my gym. Make a selection: ");
            switch (choice)
            {
                case 1:
                    CreateAccount();
                    Continue();
                    break;
                case 2:
                    ShowWorkout();
                    Continue();
                    break;
                case 3:
                    ShowActivities();
                    Continue();
                    break;
                case 4:
                    ShowFood();
                    Continue();
                    break;
                case 5:
                    Exercise();
                    Continue();
                    break;
                case 6:
                    Console.WriteLine("Thank you for checking out my gym. Hope you come by again.");
                    break;
                default:
                    Console.WriteLine("Please enter valid input.");
                    Continue();
                    break;
            }
        }
        // this method clear the console and is calling data6 in the database class
        private void Exercise()
        {
            Console.Clear();
            Database.Data6();
        }
        // this method clear the console and is calling data4 in the database class
        private void ShowFood()
        {
            Console.Clear();
            Database.Data4();
        }
        // this method clear the console and is calling data3 in the database class
        private void ShowActivities()
        {
            Console.Clear();
            Database.Data3();
        }
        // this method clear the console and is calling data2 in the database class
        private void ShowWorkout()
        {
            Console.Clear();
            Database.Data2();
        }
        // this method clear the console and is calling data5 in the database class
        private void CreateAccount()
        {
            Console.Clear();
            Database.Data5();
        }
        // This method will return back to the main menu of a menu
        private void Continue()
        {
            Console.WriteLine("Press The Return Key To Go Back To The Main Menu...");
            Console.ReadKey();
            _mymenu.Display();
            Selection();
        }
    }
}
